//
//  Models.swift
//  The Most Awesome Northwest-KC Programming Contest
//
//  Created by student on 3/14/19.
//  Copyright © 2019 Ajit. All rights reserved.
//

import Foundation


class Schools{
    static var shared = Schools()
    private var schools:[School]

    
    //    init(school: [School]) {
//        self.school = schools
//        self.schools.add(School(name: "NWMSU", coach: "ABC"))
//    }
    
    init(schools: [School]) {
//        self.school = schools
        self.schools = schools
        
        self.schools.append(School(name: "NWMSU", coach: "ABC"))
    }
    
    convenience init(){
//         self.init(school: )
        self.init(schools: [])
    }
    
    func numSchools() -> Int{
//        return school
        return schools.count
    }
    
//    subscript(index) -> School {
//        return school
    
    subscript(index:Int) -> School {
//           return school
        return schools[index]
    }
    
    func add(school:School){
        schools.append(school)
    }
    
//    func delete(school:School){
//        for i in 0 ..< schools.count {
//
    
    
    func delete(school:School){
//       for i in ..< school.count {
        
       for i in 0 ..< schools.count {
        
//        if schools() == school {
//            schools.remove(at:)
        
        if schools[i] == school {
                schools.remove(at:i)
                break
            }
        }
    }
    
}




class School:Equatable{
    var name: String
    var coach: String
    var teams: [Team]
    
    func addTeam(name: String, students: [String]){
//        print("addTeams")
//        teams.add(Team(name: "dbs", students: " "))
        print("addTeams")
        teams.append(Team(name: name, students: students))
    }
    
//    init(name: "", coach: "") {
//    self.name = name
//    self.coach = coach
//    self.teams = []
    
    init(name: String, coach: String) {
        self.name = name
        self.coach = coach
        self.teams = []
    }
    
    static func == (lhs: School, rhs: School) -> Bool {
        
//        return left.name == right.name && left.coach == right.coach && left.teams == right.teams

        return lhs.name == rhs.name && lhs.coach == rhs.coach && lhs.teams == rhs.teams
    }
}

class Team : Equatable{
    var name: String
    var students: [String]
    
//    init(name: "", students: ""){
//        self.name = name
//        self.student = student
    
    init(name: String, students: [String]){
        self.name = name
//        self.students = student
        self.students = students
    }
    
    static func == (lhs: Team, rhs: Team) -> Bool {
       
//        return left.name == right.name && left.students == right.students

        
        return lhs.name == rhs.name && lhs.students == rhs.students
    }
}





