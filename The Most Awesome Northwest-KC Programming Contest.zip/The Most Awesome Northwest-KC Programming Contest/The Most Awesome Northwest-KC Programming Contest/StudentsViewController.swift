//
//  StudentsViewController.swift
//  The Most Awesome Northwest-KC Programming Contest
//
//  Created by student on 3/14/19.
//  Copyright © 2019 Ajit. All rights reserved.
//

import UIKit

class StudentsViewController: UIViewController {
    
    @IBOutlet weak var studentLBL: UILabel!
    @IBOutlet weak var student1LBL: UILabel!
    @IBOutlet weak var student2LBL: UILabel!
    @IBOutlet weak var teamNameLBL: UILabel!
    
    var team: Team!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//         studentLBL.text = team.students
        
        studentLBL.text = team.students[0]
        
//         student1.text = team.students
        student1LBL.text = team.students[1]
        
//         student2.text = team.students0
       
        student2LBL.text = team.students[2]
//        teamName.text = team.name
//        navigationItem.name = team.name
//
        teamNameLBL.text = team.name
        
        navigationItem.title = team.name
    }
    
}
