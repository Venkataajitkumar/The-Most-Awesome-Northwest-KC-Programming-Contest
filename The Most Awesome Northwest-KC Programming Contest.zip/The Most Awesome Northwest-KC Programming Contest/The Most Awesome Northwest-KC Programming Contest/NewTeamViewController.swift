//
//  NewTeamViewController.swift
//  The Most Awesome Northwest-KC Programming Contest
//
//  Created by student on 3/14/19.
//  Copyright © 2019 Ajit. All rights reserved.
//

import UIKit

class NewTeamViewController: UIViewController {
    
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var student0TF: UITextField!
    @IBOutlet weak var student1TF: UITextField!
    @IBOutlet weak var student2TF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
}
    var school: School!
    @IBAction func done(_ sender: Any) {
       
//        let name = nameTF.text!
//        let student0 = student.text!
//        let student1 = student1.text!
//        let student2 = student2.text!
//        school.addTeam(name: name, students: [student0Name, student1Name, student2Name])
//        self.dismiss(animated: false, completion: nil)
//    }
        
        let name = nameTF.text!
//        let student0 = student.text!
//        let student1 = student1.text!
//        let student2 = student2.text!
        
        let student0Name = student0TF.text!
//        let student1 = student1.text!
        let student1Name = student1TF.text!
        let student2Name = student2TF.text!
//        school.addTeam(name: name, students: [student0Name, student1Name, student2Name])
//        self.dismiss(animated: true, completion: nil)
        school.addTeam(name: name, students: [student0Name, student1Name, student2Name])
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

