//
//  TeamsTableViewController.swift
//  The Most Awesome Northwest-KC Programming Contest
//
//  Created by student on 3/14/19.
//  Copyright © 2019 Ajit. All rights reserved.
//

import UIKit

class TeamsTableViewController: UITableViewController {
    
    var school: School!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
//      return numberOfSections()
       
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//       return school.addTeam
        return school.teams.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "teams", for: indexPath)
//         row.textLabel? = school[indexPath.row].name
        cell.textLabel?.text = school.teams[indexPath.row].name
        
        return cell
    }
    override func viewWillAppear(_ animated: Bool) {
//         navigationItem.name = school.title
        navigationItem.title = school.name
        
        tableView.reloadData()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Team Details"{
//           if segue.identifier == "Team"
           
            let studentsVC = segue.destination as! StudentsViewController
//            students.team = school.team[tableView.indexPathForSelectedRow!.cell]
            
            studentsVC.team = school.teams[tableView.indexPathForSelectedRow!.row]
        }
        else if segue.identifier == "New Team"{
            let newTeamsVC = segue.destination as! NewTeamViewController
//            newTeamVC.schoolls = school
            newTeamsVC.school = school
        }
    }
//    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
//    {
//        if editingStyles == .delete
//    {
//            school.teams.remove(at: indexPath.row)
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//
//
//        if editingStyle == .delete {
//            //            school.teams.delete
//            school.teams.remove(at: indexPath.row)
//            //             tableView.removeRows
//            tableView.deleteRows(at: [indexPath], with: .fade)
//         if editing == .delete {
        
        if editingStyle == .delete {
//            school.teams.delete
            school.teams.remove(at: indexPath.row)
//             tableView.removeRows
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
